﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Drawing.Text;
using System.IO;

namespace hocrgui
{
    public partial class Settings : Form
    {
        IList<FontInfo> InstalledFonts = new List<FontInfo>();
        public Settings()
        {
            InitializeComponent();


            
            //foreach (string font in Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Fonts)))
            //{
            //    try
            //    {
            //        PrivateFontCollection fontCol = new PrivateFontCollection();
            //        fontCol.AddFontFile(font);
            //        FontInfo i = new FontInfo();
            //        i.FilePath = font;
            //        i.Name = fontCol.Families[0].Name;
            //        InstalledFonts.Add(i);
            //    }
            //    catch (Exception) { }

            //}

            settingsBindingSource.DataSource = Properties.Settings.Default;
            settingsBindingSource.CurrentItemChanged += new EventHandler(settingsBindingSource_CurrentItemChanged);
        }

        void settingsBindingSource_CurrentItemChanged(object sender, EventArgs e)
        {
            settingsBindingSource.EndEdit();
            Properties.Settings.Default.Save();
        }

        private void Settings_Validating(object sender, CancelEventArgs e)
        {
            settingsBindingSource.EndEdit();
        }

        private void watchFolderTextBox_Click(object sender, EventArgs e)
        {
            settingsBindingSource.EndEdit();
            folderBrowserDialog1.ShowDialog();
            Properties.Settings.Default.WatchFolder = folderBrowserDialog1.SelectedPath;
            settingsBindingSource.ResetBindings(false);
        }

        private void saveOriginalFilesToTextBox_Click(object sender, EventArgs e)
        {
            settingsBindingSource.EndEdit();
            folderBrowserDialog1.ShowDialog();
            Properties.Settings.Default.SaveOriginalFilesTo = folderBrowserDialog1.SelectedPath;
            settingsBindingSource.ResetBindings(false);
        }

        private void saveProcessedFilesToTextBox_Click(object sender, EventArgs e)
        {
            settingsBindingSource.EndEdit();
            folderBrowserDialog1.ShowDialog();
            Properties.Settings.Default.SaveProcessedFilesTo = folderBrowserDialog1.SelectedPath;
            settingsBindingSource.ResetBindings(false);
        }

        private void fontNameTextBox_Click(object sender, EventArgs e)
        {
            return;
            fontDialog1.ShowDialog();
            var f = fontDialog1.Font;
            var s = f.OriginalFontName;



            foreach (var d in InstalledFonts)
            {
                if (d.Name == f.Name)
                    MessageBox.Show(d.FilePath);
            }
       
        }
    }

    public class FontInfo
    {
        public string FilePath { get; set; }
        public string Name { get; set; }
    }
}
