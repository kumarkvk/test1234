using System;
using System.Windows.Forms;

namespace hocrgui
{
	public class Program
	{
        [STAThread]
		public static void Main(string[] args)
		{
            MainWindow f = new MainWindow();
			Application.Run(f);
		}
	}
}

