﻿namespace hocrgui
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label watchFolderLabel;
            System.Windows.Forms.Label pDFAuthorLabel;
            System.Windows.Forms.Label imageTypeLabel;
            System.Windows.Forms.Label fontNameLabel;
            System.Windows.Forms.Label lanuguageLabel;
            System.Windows.Forms.Label autoOcrLabel;
            System.Windows.Forms.Label saveProcessedFilesToLabel;
            System.Windows.Forms.Label saveOriginalFilesToLabel;
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.autoOcrCheckBox = new System.Windows.Forms.CheckBox();
            this.lanuguageTextBox = new System.Windows.Forms.TextBox();
            this.fontNameTextBox = new System.Windows.Forms.TextBox();
            this.imageTypeComboBox = new System.Windows.Forms.ComboBox();
            this.pDFAuthorTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.saveProcessedFilesToTextBox = new System.Windows.Forms.TextBox();
            this.saveOriginalFilesToTextBox = new System.Windows.Forms.TextBox();
            this.useWatchFoldersCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.watchFolderTextBox = new System.Windows.Forms.TextBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.pDFSettingsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.settingsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            watchFolderLabel = new System.Windows.Forms.Label();
            pDFAuthorLabel = new System.Windows.Forms.Label();
            imageTypeLabel = new System.Windows.Forms.Label();
            fontNameLabel = new System.Windows.Forms.Label();
            lanuguageLabel = new System.Windows.Forms.Label();
            autoOcrLabel = new System.Windows.Forms.Label();
            saveProcessedFilesToLabel = new System.Windows.Forms.Label();
            saveOriginalFilesToLabel = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pDFSettingsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // watchFolderLabel
            // 
            watchFolderLabel.AutoSize = true;
            watchFolderLabel.Location = new System.Drawing.Point(6, 16);
            watchFolderLabel.Name = "watchFolderLabel";
            watchFolderLabel.Size = new System.Drawing.Size(74, 13);
            watchFolderLabel.TabIndex = 0;
            watchFolderLabel.Text = "Watch Folder:";
            // 
            // pDFAuthorLabel
            // 
            pDFAuthorLabel.AutoSize = true;
            pDFAuthorLabel.Location = new System.Drawing.Point(8, 22);
            pDFAuthorLabel.Name = "pDFAuthorLabel";
            pDFAuthorLabel.Size = new System.Drawing.Size(62, 13);
            pDFAuthorLabel.TabIndex = 0;
            pDFAuthorLabel.Text = "PDFAuthor:";
            // 
            // imageTypeLabel
            // 
            imageTypeLabel.AutoSize = true;
            imageTypeLabel.Location = new System.Drawing.Point(8, 76);
            imageTypeLabel.Name = "imageTypeLabel";
            imageTypeLabel.Size = new System.Drawing.Size(66, 13);
            imageTypeLabel.TabIndex = 2;
            imageTypeLabel.Text = "Image Type:";
            // 
            // fontNameLabel
            // 
            fontNameLabel.AutoSize = true;
            fontNameLabel.Location = new System.Drawing.Point(141, 76);
            fontNameLabel.Name = "fontNameLabel";
            fontNameLabel.Size = new System.Drawing.Size(62, 13);
            fontNameLabel.TabIndex = 4;
            fontNameLabel.Text = "Font Name:";
            // 
            // lanuguageLabel
            // 
            lanuguageLabel.AutoSize = true;
            lanuguageLabel.Location = new System.Drawing.Point(10, 132);
            lanuguageLabel.Name = "lanuguageLabel";
            lanuguageLabel.Size = new System.Drawing.Size(64, 13);
            lanuguageLabel.TabIndex = 6;
            lanuguageLabel.Text = "Lanuguage:";
            // 
            // autoOcrLabel
            // 
            autoOcrLabel.AutoSize = true;
            autoOcrLabel.Location = new System.Drawing.Point(141, 132);
            autoOcrLabel.Name = "autoOcrLabel";
            autoOcrLabel.Size = new System.Drawing.Size(52, 13);
            autoOcrLabel.TabIndex = 8;
            autoOcrLabel.Text = "Auto Ocr:";
            // 
            // saveProcessedFilesToLabel
            // 
            saveProcessedFilesToLabel.AutoSize = true;
            saveProcessedFilesToLabel.Location = new System.Drawing.Point(15, 175);
            saveProcessedFilesToLabel.Name = "saveProcessedFilesToLabel";
            saveProcessedFilesToLabel.Size = new System.Drawing.Size(109, 13);
            saveProcessedFilesToLabel.TabIndex = 8;
            saveProcessedFilesToLabel.Text = "Move finished files to:";
            // 
            // saveOriginalFilesToLabel
            // 
            saveOriginalFilesToLabel.AutoSize = true;
            saveOriginalFilesToLabel.Location = new System.Drawing.Point(15, 124);
            saveOriginalFilesToLabel.Name = "saveOriginalFilesToLabel";
            saveOriginalFilesToLabel.Size = new System.Drawing.Size(106, 13);
            saveOriginalFilesToLabel.TabIndex = 6;
            saveOriginalFilesToLabel.Text = "Move original files to:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(397, 246);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.linkLabel1);
            this.tabPage1.Controls.Add(autoOcrLabel);
            this.tabPage1.Controls.Add(this.autoOcrCheckBox);
            this.tabPage1.Controls.Add(this.lanuguageTextBox);
            this.tabPage1.Controls.Add(this.fontNameTextBox);
            this.tabPage1.Controls.Add(this.imageTypeComboBox);
            this.tabPage1.Controls.Add(this.pDFAuthorTextBox);
            this.tabPage1.Controls.Add(lanuguageLabel);
            this.tabPage1.Controls.Add(fontNameLabel);
            this.tabPage1.Controls.Add(imageTypeLabel);
            this.tabPage1.Controls.Add(pDFAuthorLabel);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(389, 220);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PDF Settings";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(250, 95);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(35, 13);
            this.linkLabel1.TabIndex = 10;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "select";
            // 
            // autoOcrCheckBox
            // 
            this.autoOcrCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.settingsBindingSource, "AutoOcr", true));
            this.autoOcrCheckBox.Location = new System.Drawing.Point(199, 127);
            this.autoOcrCheckBox.Name = "autoOcrCheckBox";
            this.autoOcrCheckBox.Size = new System.Drawing.Size(104, 24);
            this.autoOcrCheckBox.TabIndex = 9;
            this.autoOcrCheckBox.UseVisualStyleBackColor = true;
            // 
            // lanuguageTextBox
            // 
            this.lanuguageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "Lanuguage", true));
            this.lanuguageTextBox.Location = new System.Drawing.Point(11, 148);
            this.lanuguageTextBox.Name = "lanuguageTextBox";
            this.lanuguageTextBox.Size = new System.Drawing.Size(114, 20);
            this.lanuguageTextBox.TabIndex = 7;
            // 
            // fontNameTextBox
            // 
            this.fontNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "FontName", true));
            this.fontNameTextBox.Location = new System.Drawing.Point(144, 92);
            this.fontNameTextBox.Name = "fontNameTextBox";
            this.fontNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.fontNameTextBox.TabIndex = 5;
            this.fontNameTextBox.Click += new System.EventHandler(this.fontNameTextBox_Click);
            // 
            // imageTypeComboBox
            // 
            this.imageTypeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "ImageType", true));
            this.imageTypeComboBox.FormattingEnabled = true;
            this.imageTypeComboBox.Location = new System.Drawing.Point(11, 92);
            this.imageTypeComboBox.Name = "imageTypeComboBox";
            this.imageTypeComboBox.Size = new System.Drawing.Size(114, 21);
            this.imageTypeComboBox.TabIndex = 3;
            // 
            // pDFAuthorTextBox
            // 
            this.pDFAuthorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "PDFAuthor", true));
            this.pDFAuthorTextBox.Location = new System.Drawing.Point(11, 38);
            this.pDFAuthorTextBox.Name = "pDFAuthorTextBox";
            this.pDFAuthorTextBox.Size = new System.Drawing.Size(333, 20);
            this.pDFAuthorTextBox.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.saveProcessedFilesToTextBox);
            this.tabPage2.Controls.Add(this.saveOriginalFilesToTextBox);
            this.tabPage2.Controls.Add(saveProcessedFilesToLabel);
            this.tabPage2.Controls.Add(saveOriginalFilesToLabel);
            this.tabPage2.Controls.Add(this.useWatchFoldersCheckBox);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(389, 220);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Watch Folders";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // saveProcessedFilesToTextBox
            // 
            this.saveProcessedFilesToTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "SaveProcessedFilesTo", true));
            this.saveProcessedFilesToTextBox.Location = new System.Drawing.Point(18, 191);
            this.saveProcessedFilesToTextBox.Name = "saveProcessedFilesToTextBox";
            this.saveProcessedFilesToTextBox.Size = new System.Drawing.Size(291, 20);
            this.saveProcessedFilesToTextBox.TabIndex = 9;
            this.saveProcessedFilesToTextBox.Click += new System.EventHandler(this.saveProcessedFilesToTextBox_Click);
            // 
            // saveOriginalFilesToTextBox
            // 
            this.saveOriginalFilesToTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "SaveOriginalFilesTo", true));
            this.saveOriginalFilesToTextBox.Location = new System.Drawing.Point(18, 140);
            this.saveOriginalFilesToTextBox.Name = "saveOriginalFilesToTextBox";
            this.saveOriginalFilesToTextBox.Size = new System.Drawing.Size(291, 20);
            this.saveOriginalFilesToTextBox.TabIndex = 7;
            this.saveOriginalFilesToTextBox.Click += new System.EventHandler(this.saveOriginalFilesToTextBox_Click);
            // 
            // useWatchFoldersCheckBox
            // 
            this.useWatchFoldersCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.settingsBindingSource, "UseWatchFolders", true));
            this.useWatchFoldersCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useWatchFoldersCheckBox.Location = new System.Drawing.Point(9, 13);
            this.useWatchFoldersCheckBox.Name = "useWatchFoldersCheckBox";
            this.useWatchFoldersCheckBox.Size = new System.Drawing.Size(160, 24);
            this.useWatchFoldersCheckBox.TabIndex = 2;
            this.useWatchFoldersCheckBox.Text = "Use watch folders";
            this.useWatchFoldersCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.watchFolderTextBox);
            this.groupBox1.Controls.Add(watchFolderLabel);
            this.groupBox1.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", this.settingsBindingSource, "UseWatchFolders", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.groupBox1.Location = new System.Drawing.Point(9, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 68);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // watchFolderTextBox
            // 
            this.watchFolderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.settingsBindingSource, "WatchFolder", true));
            this.watchFolderTextBox.Location = new System.Drawing.Point(9, 32);
            this.watchFolderTextBox.Name = "watchFolderTextBox";
            this.watchFolderTextBox.Size = new System.Drawing.Size(291, 20);
            this.watchFolderTextBox.TabIndex = 1;
            this.watchFolderTextBox.Click += new System.EventHandler(this.watchFolderTextBox_Click);
            // 
            // pDFSettingsBindingSource
            // 
            this.pDFSettingsBindingSource.DataSource = typeof(Clock.Pdf.PDFSettings);
            // 
            // settingsBindingSource
            // 
            this.settingsBindingSource.DataSource = typeof(System.Configuration.ApplicationSettingsBase);
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 246);
            this.Controls.Add(this.tabControl1);
            this.Name = "Settings";
            this.Text = "Settings";
            this.Validating += new System.ComponentModel.CancelEventHandler(this.Settings_Validating);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pDFSettingsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.settingsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource pDFSettingsBindingSource;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox autoOcrCheckBox;
        private System.Windows.Forms.BindingSource settingsBindingSource;
        private System.Windows.Forms.TextBox lanuguageTextBox;
        private System.Windows.Forms.TextBox fontNameTextBox;
        private System.Windows.Forms.ComboBox imageTypeComboBox;
        private System.Windows.Forms.TextBox pDFAuthorTextBox;
        private System.Windows.Forms.CheckBox useWatchFoldersCheckBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox watchFolderTextBox;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox saveProcessedFilesToTextBox;
        private System.Windows.Forms.TextBox saveOriginalFilesToTextBox;
    }
}