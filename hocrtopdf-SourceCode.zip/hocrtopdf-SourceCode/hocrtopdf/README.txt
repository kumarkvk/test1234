Be sure and add the cuneiorm directory to your PATH.
By default, the Tesseract installation adds its location to the PATH.
