using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clock.Hocr
{
    public class hChar : HOcrClass
    {
        public int ListOrder { get; set; }
    }
}
